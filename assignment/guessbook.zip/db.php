<?php
 
$servername = "lrgs.ftsm.ukm.my";
$username = "a173586";
$password = "cutepinkhamster";
$dbname = "a173586";
 
?>